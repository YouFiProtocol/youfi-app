# 👋 Bem-vindo à YouFi (YouFinance)

**Transformamos metas financeiras em patrimônio digital** na **Base L2**, com UX gasless e IA.

## 🚀 Projetos
- **YouFi App** – Mini App (Base) + Next.js  
- **YouFi Contracts** – smart contracts (Foundry)  
- **YouFi Docs** – documentação pública  
- **YouFi Infra** – DevOps (Docker, NGINX, n8n)

## 🔗 Links
Website | Twitter/X | LinkedIn | Discord | Farcaster

> Build with love in Brazil 🇧🇷
