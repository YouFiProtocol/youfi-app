# Segurança & Compliance

- Segredos só em servidor/secret store.
- LGPD/HIPAA conformidade (sem PII em logs).
- Proteção de branch e revisão obrigatória.
