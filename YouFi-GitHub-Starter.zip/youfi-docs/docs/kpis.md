# KPIs
- SLO Manifest: 99.9%
- TTFD Mini App padrão: < 2h
- Erro de transação (prod): < 0.3%
- Custo médio por tx: < $0.01
