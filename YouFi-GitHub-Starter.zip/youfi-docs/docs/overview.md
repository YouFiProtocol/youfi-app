# Visão geral

YouFi transforma metas financeiras em patrimônio digital usando **Base L2**, **UX gasless** (ERC‑4337) e IA.
