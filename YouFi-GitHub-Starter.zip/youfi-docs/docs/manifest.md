# Manifesto Farcaster

1. Gere as variáveis via CLI:
```bash
npx create-onchain --manifest
```
2. Publique `/.well-known/farcaster.json` na app.
3. Enquanto testar, use `noindex: true`.
