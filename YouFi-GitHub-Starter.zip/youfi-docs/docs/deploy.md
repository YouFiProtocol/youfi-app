# Deploy (Vercel)

- Configure envs no Vercel (API key, URL, Farcaster).
- Ative previews por PR.
