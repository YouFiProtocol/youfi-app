# Gasless (Paymaster)

- Configure políticas seguras (allowlist/limites diários).
- Teste em Base Sepolia antes de produção.
