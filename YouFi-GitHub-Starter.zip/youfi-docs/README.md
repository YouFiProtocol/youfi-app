# YouFi Docs

Documentação pública e técnica do YouFi.

## Índice
- Visão geral
- Setup local
- Manifesto Farcaster
- Paymaster (gasless)
- Deploy (Vercel)
- Segurança & Compliance
- Roadmap & KPIs
