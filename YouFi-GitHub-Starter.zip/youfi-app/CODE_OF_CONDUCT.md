# Code of Conduct

We are committed to a welcoming, inclusive community. Be respectful, assume positive intent,
and follow the guidelines below:

- Be kind and professional.
- No harassment or discrimination of any kind.
- Use inclusive language.
- Report violations to security@youfi.finance.

This project follows the Contributor Covenant.
