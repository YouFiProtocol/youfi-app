## What
-

## Why
-

## Tests
- [ ] Local build succeeds
- [ ] Lint & types pass
- [ ] Manual smoke on Base Sepolia (if onchain)

## Notes
-
