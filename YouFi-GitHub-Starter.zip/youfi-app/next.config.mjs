/** @type {import('next').NextConfig} */
const nextConfig = { experimental: { optimizePackageImports: ['lucide-react'] } };
export default nextConfig;
